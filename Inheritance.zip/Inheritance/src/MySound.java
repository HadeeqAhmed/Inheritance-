public class MySound {
    public static void main(String[] args){
    Sounds mySound = new Sounds();
    Audioplayer myAudioplayer = new Audioplayer();
    mySound.playsound();

    }
}
