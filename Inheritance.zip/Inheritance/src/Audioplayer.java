
import java.util.Scanner;
abstract class Audioplayer extends Sounds {
    public abstract void play();
    public abstract void stop();
    public abstract void pause();
    public abstract void resume();
}



