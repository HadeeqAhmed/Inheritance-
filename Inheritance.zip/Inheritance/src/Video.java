interface  Video  {
    public void Display();
    public void Play();
    public void Pause();
    public void Stop();
    public void FastForward();
    public void Rewind();
    public void Next();
    public void Previous();

}
