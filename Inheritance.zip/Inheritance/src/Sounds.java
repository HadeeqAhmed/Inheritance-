class Sounds {

    public  void playsound(){
        System.out.println(" Sound is Playing");
    }
    public  void stopsound(){
        System.out.println(" Sound  is Stopped");
    }
    public  void pausesound(){
        System.out.println(" Sound is Paused");
    }
    public  void resumesound(){
        System.out.println(" Sound is Resuming");
    }

}
